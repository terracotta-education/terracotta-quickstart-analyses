Terracotta Experiment Data Export

Overview

Terracotta is a platform designed to lower the technical and methodological barriers to conducting rigorous and responsible education research. This folder contains an export of data for an experiment that used Terracotta and includes files about the construction of the experiment, recorded participant data, and outcome data. For more information on Terracotta as a whole, please visit terracotta.education. You will find the data dictionary in its entirety at terracotta.education/help-center/data-dictionary.

Files Provided

-experiment.csv: general experiment data
-participants.csv: consent related data for participants
-participant_treatment.csv: ordering and distribution of assignments for testing along with experimental conditions
-submissions.csv: record of the participant submission and assignment data
-items.csv: a collection of elements within an assignment
-response_options.csv: the collection of responses available for an item
-outcomes.csv: results in reference to baseline measures

How to use

The data exported from Terracotta into the zip file can have numerous applications. One might begin by importing the .csv files into data visualization software to help represent the data in a clear and concise manner. The outcomes.csv file will likely prove most useful when generating a report on the outcomes of your experiments, as it will help to determine which hypotheses were correct or incorrect, and facilitate conversation for further exploration. The experiment.csv file will also be useful in a summary representation of the experiments. The files participants.csv, participant_treatment.csv, submissions.csv, and item_responses.csv will help demonstrate the experimental journey in aggregate. The remaining files, items.csv and response_options.csv, are helpful for referencing the assignments used for the experiment.

Credits
-Tyler Sterle: Technical Writer
-Benjamin Motz: Principal Investigator
-Harmony Jankowski: Project Manager

License
Trustees of Indiana University